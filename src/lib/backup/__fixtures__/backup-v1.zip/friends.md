# Friends

FaceMango backup · format 1

---
type: persona
id: f1
author: Friend f1
timestamp: 1970-01-01T00:00:00.001Z
image: avatars/f1.svg
data:
  id: f1
  kind: friend
  name: Friend f1
  gender: female
  age: 30
  city: Chennai
  country: India
  languages:
    - English
  occupation: Teacher
  interests:
    - music
  likes: []
  dislikes: []
  writingStyle: warm
  agreeableness: 0.5
  stance: fan
  activity: 0.5
  closeness: 0.5
  avatar:
    style: personas
    seed: f1
  createdAt: 1
---
Friend f1 (friend) · 30 · Teacher · Chennai, India

---
type: persona
id: f2
author: Friend f2
timestamp: 1970-01-01T00:00:00.001Z
image: avatars/f2.svg
data:
  id: f2
  kind: friend
  name: Friend f2
  gender: female
  age: 30
  city: Chennai
  country: India
  languages:
    - English
  occupation: Teacher
  interests:
    - music
  likes: []
  dislikes: []
  writingStyle: warm
  agreeableness: 0.5
  stance: fan
  activity: 0.5
  closeness: 0.5
  avatar:
    style: personas
    seed: f2
  createdAt: 1
---
Friend f2 (friend) · 30 · Teacher · Chennai, India

---
type: persona
id: p1
author: Friend p1
timestamp: 1970-01-01T00:00:00.001Z
image: avatars/p1.svg
data:
  id: p1
  kind: public
  name: Friend p1
  gender: female
  age: 30
  city: Chennai
  country: India
  languages:
    - English
  occupation: Teacher
  interests:
    - music
  likes: []
  dislikes: []
  writingStyle: warm
  agreeableness: 0.5
  stance: fan
  activity: 0.5
  closeness: 0.5
  avatar:
    style: personas
    seed: p1
  createdAt: 1
---
Friend p1 (public) · 30 · Teacher · Chennai, India

---
type: persona
id: x1
author: Friend x1
timestamp: 1970-01-01T00:00:00.001Z
image: avatars/x1.svg
data:
  id: x1
  kind: former
  name: Friend x1
  gender: female
  age: 30
  city: Chennai
  country: India
  languages:
    - English
  occupation: Teacher
  interests:
    - music
  likes: []
  dislikes: []
  writingStyle: warm
  agreeableness: 0.5
  stance: fan
  activity: 0.5
  closeness: 0.5
  avatar:
    style: personas
    seed: x1
  createdAt: 1
---
Friend x1 (former) · 30 · Teacher · Chennai, India
