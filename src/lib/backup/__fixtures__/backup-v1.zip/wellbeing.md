# Wellbeing

FaceMango backup · format 1

---
type: usageSession
id: s1
timestamp: 1970-01-01T00:00:00.001Z
data:
  id: s1
  startedAt: 1
  endedAt: 2
  activeMs: 60000
---
1 min
