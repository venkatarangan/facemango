# Feed

FaceMango backup · format 1

---
type: post
id: friend-post
author: Friend f1
timestamp: 2026-11-14T13:35:28.228Z
image: pack:x
data:
  id: friend-post
  authorId: f1
  text: Hello
  photo: pack:x
  mentions: []
  createdAt: 1794663328228
  plannedComments: 0
  plannedLikes: 0
  reactionCounts: {}
  commentCount: 0
---
Hello

---
type: comment
id: c1
author: Friend f1
timestamp: 1970-01-01T00:00:00.005Z
data:
  id: c1
  postId: 0ef3f09b-e77f-4fca-a131-4951dd30a665
  authorId: f1
  text: Lovely!
  createdAt: 5
---
Lovely!
