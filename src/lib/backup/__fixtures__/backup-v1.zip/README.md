# FaceMango backup

Created 2026-11-14T13:35:28.232Z · format 1

Restore it in FaceMango: Settings → Backup & restore, or "Restore from a backup" on the welcome screen.
Photo-pack images are referenced by id (pack:…), not copied.
