# Me

FaceMango backup · format 1

---
type: profile
id: me
timestamp: 2026-11-14T13:35:28.224Z
image: images/4fd2f483-716c-4fae-af14-28c295fc0cda.webp
data:
  id: me
  name: Asha Test
  age: 30
  city: Madurai
  languages:
    - Tamil
  photoId: 4fd2f483-716c-4fae-af14-28c295fc0cda
  createdAt: 1794663328224
  dataNoticeAcknowledgedAt: 1794663328224
---
Asha Test, 30, Madurai. Speaks Tamil.

---
type: post
id: 0ef3f09b-e77f-4fca-a131-4951dd30a665
author: me
timestamp: 2026-11-14T13:35:28.228Z
image: images/66dee621-8a28-4e5d-9d3d-52b4d9f98959.webp
data:
  id: 0ef3f09b-e77f-4fca-a131-4951dd30a665
  authorId: me
  text: |-
    A post
    ---
    with a fence line
  photo: 66dee621-8a28-4e5d-9d3d-52b4d9f98959
  mentions: []
  createdAt: 1794663328228
  plannedComments: 0
  plannedLikes: 0
  reactionCounts: {}
  commentCount: 1
---
A post
- - -
with a fence line

---
type: comment
id: a93419e8-c3ed-4d13-b00a-cdf23bcfeaa7
author: me
timestamp: 2026-11-14T13:35:28.228Z
data:
  id: a93419e8-c3ed-4d13-b00a-cdf23bcfeaa7
  postId: 0ef3f09b-e77f-4fca-a131-4951dd30a665
  authorId: me
  text: my comment
  createdAt: 1794663328228
---
my comment
